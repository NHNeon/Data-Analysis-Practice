
# 🧾 FMCG Company MySQL Database for Business & Data Analysis

This project provides a **robust MySQL database schema** tailored for **Fast-Moving Consumer Goods (FMCG)** companies. Designed for business analysts, data engineers, and BI teams, the schema supports detailed **data analysis**, **financial insights**, **supply chain monitoring**, and **customer behavior modeling**.

---

## 🚀 Key Objectives

- Analyze sales performance across regions and channels  
- Track stock levels, procurement, and reorder thresholds  
- Monitor customer loyalty, segmentation, and return patterns  
- Evaluate marketing campaign performance and ROI  
- Identify profitability drivers and cost leakages  

---

## 🗂️ Database Schema Overview

### 1. `products`
Track all inventory items with price, brand, category, and stock alerts.

### 2. `suppliers`
Manage supplier relationships, regions, and contacts.

### 3. `purchases`
Store procurement records from suppliers with quantity and pricing.

### 4. `customers`
Customer profiles with demographics, region, and segment tags.

### 5. `orders`
Capture orders by customers, with delivery and payment metadata.

### 6. `order_details`
Line-level product sales data, quantity, price, and computed totals.

### 7. `payments`
Track payment completion, date, and method with status.

### 8. `sales_targets`
Monthly regional sales targets and actuals with computed goal success.

### 9. `marketing_campaigns`
Campaign metadata across channels (TV, social, email, POS, etc.)

### 10. `campaign_product_links`
Link products to specific marketing campaigns.

### 11. `returns`
Customer return reasons, approval status, and refundable quantity.

---

## 📊 Sample Queries

### 🔹 Top-Selling Products
```sql
SELECT p.name, SUM(od.quantity) AS total_units_sold
FROM order_details od
JOIN products p ON p.product_id = od.product_id
GROUP BY p.name
ORDER BY total_units_sold DESC
LIMIT 10;
```

### 🔹 Monthly Revenue
```sql
SELECT DATE_FORMAT(order_date, '%Y-%m') AS month, SUM(od.total_price) AS revenue
FROM order_details od
JOIN orders o ON o.order_id = od.order_id
GROUP BY month
ORDER BY month;
```

### 🔹 Low Stock Alerts
```sql
SELECT name, stock_quantity, reorder_level
FROM products
WHERE stock_quantity <= reorder_level;
```

### 🔹 Campaign ROI
```sql
SELECT mc.name AS campaign, mc.budget, SUM(od.total_price) AS revenue_generated,
       (SUM(od.total_price) - mc.budget) AS roi
FROM marketing_campaigns mc
JOIN campaign_product_links cpl ON mc.campaign_id = cpl.campaign_id
JOIN order_details od ON od.product_id = cpl.product_id
JOIN orders o ON o.order_id = od.order_id
WHERE o.order_date BETWEEN mc.start_date AND mc.end_date
GROUP BY mc.name, mc.budget;
```

---

## 📁 Future Enhancements

- 📈 Power BI / Tableau dashboards  
- 🧠 Machine learning modules (e.g. demand forecasting)  
- 🔁 Stored procedures for automation  
- ⏱ Real-time alert system using triggers  

---

## 📌 How to Use

1. Clone this repo  
2. Import the SQL schema into MySQL Workbench or CLI  
3. Run the sample queries to begin your analysis  
4. Connect to Power BI, Python (pandas), or Tableau for visualization  

---

## 💼 Author

**Nazmul Haque**  
Business Analyst | Data Enthusiast  
🌍 Bangladesh 🇧🇩  
🔗 [LinkedIn](https://www.linkedin.com) | ✉️ nazmul@example.com

---

> *“Data beats emotions. Make data-driven FMCG decisions—faster, smarter, better.”*
